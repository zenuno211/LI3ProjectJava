C libraries
