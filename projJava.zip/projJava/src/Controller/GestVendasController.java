package Controller;

import Model.*;
import Utils.*;
import View.*;
import Exceptions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.io.IOException;
import java.lang.Number;

public class GestVendasController implements IGestVendasController{
    private IGestVendasModel gestVendasModel;
    private IGestVendasView gestVendasView;

    public GestVendasController(){
        this.gestVendasModel = new GestVendasModel();
        this.gestVendasView = new GestVendasView();
    }

    public void startController(){
        boolean next = false;

        /* Carregamento de ficheiro binário / Escolha de ficheiro de venda */
        try{
            this.gestVendasView.loading();
            this.gestVendasModel = this.gestVendasModel.load("gestVendas.dat");
        } catch(IOException | ClassNotFoundException e){
            while(!next){
                this.gestVendasView.chooseVenda("gestVendas.dat", true);
                String v = Input.lerString();
                switch(v){
                    case "1":
                        this.gestVendasView.loading();
                        this.gestVendasModel = new GestVendasModel("input_files/Vendas_1M.txt");
                        next = true;
                        break;
                    case "2":
                        this.gestVendasView.loading();
                        this.gestVendasModel = new GestVendasModel("input_files/Vendas_3M.txt");
                        next = true;
                        break;
                    case "3":
                        this.gestVendasView.loading();
                        this.gestVendasModel = new GestVendasModel("input_files/Vendas_5M.txt");
                        next = true;
                        break;
                    default:
                        this.gestVendasView.showErro("ficheiro de venda");
                        break;
                }
            }
        }

        /* Stats do ficheiro de vendas */
        IStatsVenda sv = this.gestVendasModel.getStatsVenda();

        this.gestVendasView.showStatsVenda(sv);
        Input.lerString();

        /* Menu principal */
        boolean run = true;
        while(run) {
            this.gestVendasView.showMenu();
            String option = Input.lerString();
            Crono.start();
            switch(option){
                case "Q":
                    run = false;
                    break;
                case "S":
                    save();
                    break;
                case "L":
                    load();
                    break;
                    
                case "T":
                    textFileLoad();
                    break;

                case "0":
                    queryStats();
                    break;
                
                case "1":
                    query1();
                    break;

                case "2": 
                    query2();
                    break;

                case "3":
                    query3();
                    break;

                case "4":
                    query4();
                    break;

                case "5":
                    query5();
                    break;

                case "6":
                    query6();
                    break;

                case "7":
                    query7();
                    break;

                case "8":
                    query8();
                    break;
                case "9":
                    query9();
                    break;

                case "10":
                    query10();
                    break;

                default:
                    this.gestVendasView.showErroOpcao();
                    Input.lerString();
                    break;
            }

        }

        this.gestVendasView.showExitMessage();
    }

    private void menuList(List<String> lista, String titulo){
        int listSize = lista.size();
        int numPages = 0;

        int maxPageSize = 64;
    
        if (listSize % maxPageSize == 0) numPages = listSize/maxPageSize;
        else numPages = (listSize/maxPageSize) + 1;
    
        int currentPage = 1;
        int pageSize = maxPageSize;
    
        boolean exit = false;
        String option;
        int listLeft = 0;
    
        while(!exit){
            listLeft = (listSize - (pageSize * (currentPage - 1)));
            if (maxPageSize > listLeft) pageSize = listLeft;
            else pageSize = maxPageSize;
    
            this.gestVendasView.showPageLista(titulo, lista, currentPage, pageSize , numPages, listSize);
    
            option = Input.lerString();
    
            switch(option){
                case "1":
                    if (currentPage > 1) currentPage--;
                    break;
                case "2":
                    if (currentPage < numPages ) currentPage++;
                    break;
                case "3":
                    if(numPages > 1) {
                        this.gestVendasView.showGet("a página");
                        currentPage = Input.lerInt();
                        if (currentPage > numPages) currentPage = numPages;
                        if (currentPage < 1) currentPage = 1;
                    }
                    break;
                case "Q":
                    exit = true;
                    break;
                default:
                    break;
            }
        }
    }

    private void menuMap(Map<String, ? extends Number> map, String titulo){
        int mapSize = map.size();
        int numPages = 0;
        int maxPageSize = 64;
    
        if (mapSize % maxPageSize == 0) numPages = mapSize/maxPageSize;
        else numPages = (mapSize/maxPageSize) + 1;
    
        int currentPage = 1;
        int pageSize = maxPageSize;
    
        boolean exit = false;
        String option;
        int mapLeft = 0;
    
        while(!exit){
            mapLeft = (mapSize - (pageSize * (currentPage - 1)));
            if (maxPageSize > mapLeft) pageSize = mapLeft;
            else pageSize = maxPageSize;
    
            this.gestVendasView.showPageMap(titulo, map, currentPage, pageSize , numPages, mapSize);
    
            option = Input.lerString();
    
            switch(option){
                case "1":
                    if (currentPage > 1) currentPage--;
                    break;
                case "2":
                    if (currentPage < numPages ) currentPage++;
                    break;
                case "3":
                    if(numPages > 1) {
                        this.gestVendasView.showGet("a página");
                        currentPage = Input.lerInt();
                        if (currentPage > numPages) currentPage = numPages;
                        if (currentPage < 1) currentPage = 1;
                    }
                    break;
                case "Q":
                    exit = true;
                    break;
                default:
                    break;
            }
        }
    }

    private void textFileLoad(){
        boolean next = false;
        while(!next){
            this.gestVendasView.chooseVenda("", false);
            String v = Input.lerString();
            switch(v){
                case "1":
                    this.gestVendasView.loading();
                    this.gestVendasModel = new GestVendasModel("input_files/Vendas_1M.txt");
                    next = true;
                    break;
                case "2":
                    this.gestVendasView.loading();
                    this.gestVendasModel = new GestVendasModel("input_files/Vendas_3M.txt");
                    next = true;
                    break;
                case "3":
                    this.gestVendasView.loading();
                    this.gestVendasModel = new GestVendasModel("input_files/Vendas_5M.txt");
                    next = true;
                    break;
                case "Q":
                    next = true;
                    break;
                default:
                    this.gestVendasView.showErro("ficheiro de venda");
                    break;
            }
        }
    }

    private void save(){
        try{
            this.gestVendasView.showGet(" ficheiro para gravar");
            String fileName = Input.lerString();

            this.gestVendasView.saving();
            this.gestVendasModel.save(fileName);

            this.gestVendasView.saved(fileName);
        } catch(IOException e){
            this.gestVendasView.showErro("ficheiro");
        }
    }

    private void load(){
        Scanner input = new Scanner(System.in);
        try{
            this.gestVendasView.showGet(" ficheiro para carregar");
            String fileName = Input.lerString();

            this.gestVendasView.loading();
            this.gestVendasModel = this.gestVendasModel.load(fileName);

            this.gestVendasView.saved(fileName);
        } catch(ClassNotFoundException | IOException e){
            this.gestVendasView.showErro("ficheiro");
            Input.lerString();
        }
        input.close();
    }

    private void queryStats(){
        int[] comprasPorMesStats = this.gestVendasModel.getNumTotalComprasMes();
        double[][] totalFaturadoStats = this.gestVendasModel.getFaturacaoTotalFilialMes();
        int[][] numClientesStats = this.gestVendasModel.getNumClientesCompradoresFilialMes();
        double faturacaoTotal = this.gestVendasModel.getFaturacaoTotal();
    
        this.gestVendasView.showTime(Crono.getTime());
        Input.lerString();

        this.gestVendasView.showStats1(comprasPorMesStats, totalFaturadoStats, numClientesStats, faturacaoTotal);
        Input.lerString();
    }

    private void query1(){
        List<String> listaQ1 = this.gestVendasModel.getListaProdutosNuncaComprados();

        this.gestVendasView.showTime(Crono.getTime());
        Input.lerString();

        this.menuList(listaQ1, "Numero de produtos nunca comprados");
    }

    private void query2(){
        try{
            this.gestVendasView.showGet(" mes");
            int mes = Input.lerInt();

            Crono.start();
            int totalVendas = this.gestVendasModel.getTotalVendasMes(mes);
            int numCompradores = this.gestVendasModel.getNumCompradoresMes(mes);
            int[] totalVendasFilial = this.gestVendasModel.getTotalVendasPorFilialMes(mes);
            int[] numCompradoresFilial = this.gestVendasModel.getNumClientesCompradoresPorFilialMes(mes);

            this.gestVendasView.showTime(Crono.getTime());
            Input.lerString();

            this.gestVendasView.showQ2(totalVendas, totalVendasFilial, numCompradores, numCompradoresFilial, mes);
            Input.lerString();
        } catch (MesInvalidoException e){
            this.gestVendasView.showErro("mes");
            Input.lerString();
        }
    }

    private void query3(){
        try{
            this.gestVendasView.showGet(" cliente");
            String clienteID = Input.lerString();

            Crono.start();
            int[] numProdsComprados = this.gestVendasModel.getNumProdutosCompradosCliente(clienteID);
            double[] gasto = this.gestVendasModel.getGastoCliente(clienteID);
            int[] numCompras = this.gestVendasModel.getNrComprasMes(clienteID);

            this.gestVendasView.showTime(Crono.getTime());
            Input.lerString();

            this.gestVendasView.showQ3(numProdsComprados, gasto, numCompras, clienteID);
            Input.lerString();
        } catch (ClienteInvalidoException e){
            this.gestVendasView.showErro("cliente");
            Input.lerString();
        }
    }

    private void query4(){
        try{
            this.gestVendasView.showGet(" produto");
            String produtoID = Input.lerString();
    
            Crono.start();
            int[] numVendas = this.gestVendasModel.getNumVendasProdutoMes(produtoID);
            double[] totalFaturado = this.gestVendasModel.getTotalFaturadoProdutoMes(produtoID);
            int[] numClientes = this.gestVendasModel.getNumClientesCompradoresProdutoMes(produtoID);
    
            this.gestVendasView.showTime(Crono.getTime());
            Input.lerString();
    
            this.gestVendasView.showQ4(numVendas, totalFaturado, numClientes, produtoID);
            Input.lerString();
        } catch (ProdutoInvalidoException e){
            this.gestVendasView.showErro("produto");
            Input.lerString();
        }
    }

    private void query5(){
        try{
            this.gestVendasView.showGet(" cliente");
            String clienteID = Input.lerString();

            Crono.start();
            List<String> listaQ5 = this.gestVendasModel.getListaProdutosCompradosCliente(clienteID);
            
            this.gestVendasView.showTime(Crono.getTime());
            Input.lerString();

            this.menuList(listaQ5, "Número de produtos comprados por " + clienteID);
        } catch (ClienteInvalidoException e){
            this.gestVendasView.showErro("cliente");
            Input.lerString();
        }
    }

    private void query6(){
        try{
            this.gestVendasView.showGet(" limite");
            int limit = Input.lerInt();

            Crono.start();
            Map<String, Integer> mapQ6 = this.gestVendasModel.getProdutosMaisVendidos(limit);

            this.gestVendasView.showTime(Crono.getTime());
            Input.lerString();

            this.menuMap(mapQ6, "Produto - Clientes distintos\nLimite");
        } catch (LimiteInvalidoException e){
            this.gestVendasView.showErro("limite");
            Input.lerString();
        }
    }

    private void query7(){
        List<List<String>> listQ7 = new ArrayList<List<String>>();
        listQ7.add(this.gestVendasModel.getMaioresCompradores(1));
        listQ7.add(this.gestVendasModel.getMaioresCompradores(2));
        listQ7.add(this.gestVendasModel.getMaioresCompradores(3));

        this.gestVendasView.showTime(Crono.getTime());
        Input.lerString();

        this.gestVendasView.showQ7(listQ7);
        Input.lerString();
    }

    private void query8(){
        try {
            this.gestVendasView.showGet(" limite");
            int limitQ8 = Input.lerInt();

            Crono.start();
            Map<String, Integer> maisCompradores = this.gestVendasModel.getMaisCompradores(limitQ8);

            this.gestVendasView.showTime(Crono.getTime());
            Input.lerString();

            this.menuMap(maisCompradores, "Cliente - Nº de Produtos distintos\nLimite");
        } catch (LimiteInvalidoException e){
            this.gestVendasView.showErro("limite");
            Input.lerString();
        }
    }
    private void query9(){
        try{
            this.gestVendasView.showGet(" produto");
            String produtoID = Input.lerString();
            
            Crono.start();
            Map<String, Double> clientesMaisCompraram = this.gestVendasModel.getClientesMaisCompraram(produtoID);

            this.gestVendasView.showTime(Crono.getTime());
            Input.lerString();
        
            this.menuMap(clientesMaisCompraram, "Cliente - Valor Gasto\nNº de clientes que compraram " + produtoID);
        } catch (ProdutoInvalidoException e){
            this.gestVendasView.showErro("produto");
            Input.lerString();
        }
    }

    private void query10(){
        Map<String, double[][]> fatTotal = this.gestVendasModel.getFaturacaoTotalPorProduto();

        this.gestVendasView.showTime(Crono.getTime());
        Input.lerString();

        boolean quit = false;
        boolean valido = false;

        while(!quit){
            valido = false;
            this.gestVendasView.showQuit();
            this.gestVendasView.showGet(" produto");
            String produtoID = Input.lerString();
            switch(produtoID){
                case "Q":
                    quit = true;
                    break;
                default:
                    valido = this.gestVendasModel.hasProduto(produtoID);
                    if (valido){
                        this.gestVendasView.showQ10(produtoID, fatTotal.get(produtoID));
                        Input.lerString();
                    } else {
                        this.gestVendasView.showErro("produto");
                        Input.lerString();
                    }
                    break;
            }
        }
    }
}