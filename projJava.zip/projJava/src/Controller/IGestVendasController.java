package Controller;

public interface IGestVendasController {    
    /**
     * Inicia o Controller
     */
    public void startController();
}