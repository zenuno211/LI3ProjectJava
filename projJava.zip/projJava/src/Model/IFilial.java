package Model;

import java.util.Set;
import java.util.List;
import java.util.Map;

public interface IFilial {

    /**
     * Adiciona uma venda a um filial
     */
    public void addVenda(IVenda v);

    /**
     * Devolve o total faturado para um dado mes
     */
    public double getFaturacaoTotalMes(int mes);

    /**
     * Devolve o numero de clientes compradores de um dado produto
     */
    public Integer getNumClientesCompradores(String prodID);

    /**
     * Devolve um Set contendo os codigos dos clientes que efetuaram compras neste filial
     */
    public Set<String> getClientesCompradores();

    /**
     * Devolve o numero de clientes que efeturam compras num dado mes
     */
    public int getNumClientesCompradores(int mes);

    /**
     * Devolve um Set contendo os codigos dos produtos que foram comprados 
     */
    public Set<String> getProdutosComprados();

    /**
     * Devolve a lista de todos os clientes que realizaram compras mas por ordem decrescente de total faturado
     */
    public List<String> getMaioresCompradores();

    /**
     * Devolve o numero de produtos comprados por um dado cliente num determinado mes
     */
    public int getNumProdutosCompradosCliente(String ClienteID, int mes);

    /**
     * Devolve o total gasto por um dado cliente num detrminado mes
     */
    public double getGastoCliente(String clienteID, int mes);
    
    /**
     * Devolve o numero de compras efetuadas por um dado cliente num detrminado mes
     */
    public int getNrComprasMes(String clienteID, int mes);

    /**
     * Devolve o numero de clientes que compraram um dado produto num determinado mes
     */
    public int getNumCompradores(String produtoID, int mes);
       
    /**
     * Devolve a lista de codigos de clientes que compraram um dado produto
     */
    public List<String> getClientesCompradores(String produtoID);

    /**
     * Devolve um map que associa o ID de cada cliente ao nº de produtos comprados
     */
    public Map<String, Integer> getListaProdutosCompradosCliente(String clienteID);

    /**
     * Devolve o nº de produtos que um dado cliente comprou
     */
    public int getNumProdutosComprados (String clienteID);

    /**
     * Devolve a quantidade que um cliente comprou de um dado produto
     */
    public int getQuantidadeCompradaPorCliente(String produtoID, String clienteID);

   
    /**
     * Devolve o valor gasto por um certo cliente para um dado produto
     */
    public Double getValorGastoPorCliente(String produtoID, String clienteID);
}