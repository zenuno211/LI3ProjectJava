package Model;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import Exceptions.*;

public interface IGestVendasModel {
    /**
     * Devolve o Nº de produtos comprados
     */
    public int getTotalProdutosComprados();

    /**
     * Devolve o nº de vendas invalidas 
     */
    public int getVendasInvalidas();

    /**
     * Devolve o numero de vendas validas
     */
    public int getVendasValidas();

    /**
     * Devolve o numero de vendas lidas
     */
    public int getVendasLidas();

    /**
     * Devolve o numero total de produtos
     */
    public int getTotalProdutos();

    /**
     * Devolve o numero total de produtos nao comprados
     */
    public int getTotalProdutosNaoComprados();

    /**
     * Devolve o numero total de clientes 
     */
    public int getTotalClientes();

    /**
     * Devolve o numero de clientes que realizaram compras
     */
    public int getTotalClientesCompradores();

    /**
     * Devolve o numero de clientes que nao realizaram compras
     */
    public int getTotalClientesNaoCompradores();

    /**
     * Devolve o numero de vendas em que o total faturado foi zero
     */
    public long getTotalComprasZero();

    /**
     * Devolve a faturacao total
     */
    public double getFaturacaoTotal();
    
    /**
     * Dado um filial, a funcao devolve o total faturado dividido por mes nesse filial
     */
    public double[] getFaturacaoTotalFilialMes(int filial);

    /**
     * Devolve o total faturado divido por filial e por mes
     */
    public double[][] getFaturacaoTotalFilialMes();

    /**
     * Devolve o numero total de vendas dividido por mes 
     */
    public int[] getNumTotalComprasMes();

    /**
     * Devolve o numero total de compradores em cada mes, filial a filial
     */
    public int[][] getNumClientesCompradoresFilialMes();

    /**
     * Devolve uma classe StatsVenda carregando-a com a informacao 
     */
    public IStatsVenda getStatsVenda();

    /**
     * Dado um produto, devolve false caso este nao exista e true caso contrario
     */
    public boolean hasProduto(String produtoID);

    
    //Query 1
    /**
     * Devolve a lista de produtos nunca comprados
     */
    public List<String> getListaProdutosNuncaComprados();

    //Query 2
    /**
     * Devolve o nº de vendas num dados mês
     */
    public int getTotalVendasMes(int mes) throws MesInvalidoException;
    
    /**
     * Devolve o nº de vendas para cada filial num dado de mês
     */
    public int[] getTotalVendasPorFilialMes(int mes) throws MesInvalidoException;
    
    /**
     * Devolve o nº de compradores num dado mês
     */
    public int getNumCompradoresMes(int mes) throws MesInvalidoException;

    /**
     * Devolve o nº de compradores para cada filial num dado mês
     */
    public int[] getNumClientesCompradoresPorFilialMes(int mes) throws MesInvalidoException;

    //Query 3
    /**
     * Devolve o nº de produtos comprados por um dado cliente
     */
    public int[] getNumProdutosCompradosCliente(String clienteID) throws ClienteInvalidoException;

    /**
     * Devolve o dinheiro gasto por um dado cliente
     */
    public double[] getGastoCliente (String clienteID) throws ClienteInvalidoException;

    /**
     * Devolve o nº de compras feitas por um dado cliente para cada filial
     */
    public int[] getNrComprasMes(String clienteID) throws ClienteInvalidoException;

    //Query 4
    /**
     * Devolve o nº de vendas de um dado produto em cada mês
     */
    public int[] getNumVendasProdutoMes(String produtoID) throws ProdutoInvalidoException;

    /**
     * Devolve o total faturado por um dado produto em cada mês
     */
    public double[] getTotalFaturadoProdutoMes(String produtoID) throws ProdutoInvalidoException;
    
    /**
     * Devolve o nº de clientes que compraram um dao produto em cda mẽs
     */
    public int[] getNumClientesCompradoresProdutoMes(String produtoID) throws ProdutoInvalidoException;

    /* Query 5 */
    
    /**
     * Devolve a lista dos produtos mais comprado por um dado cliente
     */
    public List<String> getListaProdutosCompradosCliente(String clienteID) throws ClienteInvalidoException;

    /**
     * Devolve um Map dos X produtos mais vendidos (produtos associados aos nº de clientes que o compraram)
     */
    public Map<String, Integer> getProdutosMaisVendidos(int limit) throws LimiteInvalidoException;

    /**
     * Dada uma filial, devolve a lista dos 3 maiores compradores nessa filial
     */
    public List<String> getMaioresCompradores(int filial);

    /**
     * Devolve um map com tamanho igual ao numero de clientes requisitado pelo utilizador, 
     * e que associa os clientes que o compraram com a quantidade comprada
     */
    public Map<String,Integer> getMaisCompradores(int limit) throws LimiteInvalidoException;

    /**
     * Dado um produto, devolve um map que associa os clientes que o compraram ao total gasto por estes na compra do produto
     */
    public Map<String, Double> getClientesMaisCompraram(String produtoID) throws ProdutoInvalidoException;
    
    /**
     *Devolve a faturacao total de um dado produto dividida por mes e filial 
     */
    public double[][] getFaturacaoTotalPorProduto(String prodID) throws ProdutoInvalidoException;
    
    /**
     * Devolve um map que associa os produtos ao total faturado com o mesmo, divida por mes e filial
     */
    public Map<String, double[][]> getFaturacaoTotalPorProduto();

    /**
     * Metodo responsavel por guardar os dados da aplicacao num dado ficheiro
     */    
    public void save(String fileName) throws IOException;

    /**
     * Metodo responsavel por carregar o ficheiro binário dado
     */
    public GestVendasModel load(String fileName) throws IOException, ClassNotFoundException;
}