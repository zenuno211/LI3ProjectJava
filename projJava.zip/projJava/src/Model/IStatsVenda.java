package Model;

public interface IStatsVenda {

    /**
     * Getters para as variáveis de instância
     */

     
    public String getFile();
    public int getVendasErradas();
    public int getVendasZero();
    public int getProdutos();
    public int getProdutosComprados();
    public int getProdutosNaoComprados();
    public int getClientes();
    public int getClientesNaoCompram();
    public int getClientesCompram();
    public double getFaturacaoTotal();
}