package Model;

public interface IProdutoDeCliente {

    /**
     * Adiciona uma venda a um prods
     */
    public void addVenda(IVenda v);

    /**
     * Devolve a quantidade vendida num dado mes 
     */
    public int getQuantidade(int mes);

    /**
     * verifica se o produto foi comprado
     */
    public boolean comprado(int mes);

    /**
     * devolve a quantidade total
     */
    public int getQuantidade();
}