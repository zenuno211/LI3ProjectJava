package Model;

import java.io.Serializable;

public class Venda implements IVenda, Serializable{
    private static final long serialVersionUID = -982094434545311492L;
    private String clienteID;
    private String produtoID;
    private int quantidade;
    private double preco;
    private boolean tipo; //True - Promoção, False - Normal
    private int mes;
    private int filial;

    public Venda(String produtoID, String clienteID, int quantidade, double preco, boolean tipo, int mes, int filial){
        this.clienteID = clienteID;
        this.produtoID = produtoID;
        this.quantidade = quantidade;
        this.preco = preco;
        this.tipo = tipo;
        this.mes = mes;
        this.filial = filial;
    }

    public Venda(Venda v){
        this.clienteID = v.getClienteID();
        this.produtoID = v.getProdutoID();
        this.filial = v.getFilial();
        this.preco = v.getPreco();
        this.tipo = v.getTipo();
        this.mes = v.getMes();
        this.quantidade = v.getQuantidade();
    }

    public String getProdutoID() {
        return produtoID;
    }

    public String getClienteID() {
        return clienteID;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public boolean getTipo() {
        return tipo;
    }

    public int getMes() {
        return mes;
    }

    public int getFilial() {
        return filial;
    }

    public boolean isValid(){
        return this.preco >= 0 && this.preco <= 999.99 
            && this.quantidade >= 0 && this.quantidade <= 200 
            && this.mes >=1 && this.mes <= 12 
            && this.filial >= 1 && this.filial <= 3;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Venda: ").append(this.clienteID).append("\n")
                            .append(this.produtoID).append("\n")
                            .append(this.quantidade).append("\n")
                            .append(this.preco).append("\n")
                            .append(this.tipo).append("\n")
                            .append(this.mes).append("\n")
                            .append(this.filial).append("\n");
        return sb.toString();
    }


    public boolean equals (Object o){
        if (o == this) return true;
        if (o == null || o.getClass() != this.getClass()) return false;
        Venda v = (Venda) o;
        return this.clienteID.equals(v.getClienteID()) &&
                this.produtoID.equals(v.getProdutoID()) &&
                this.quantidade == v.getQuantidade() &&
                this.preco == v.getPreco() &&
                this.tipo == v.getTipo() && 
                this.mes == getMes() &&
                this.filial == getFilial();

    }

    
    public IVenda clone(){
        return new Venda(this);
    }

}