package Model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class CliProd implements ICliProd, Serializable{
    private static final long serialVersionUID = 4939484023145585061L;
    private String clienteID;
    private Map<String,IProdutoDeCliente> prodsMap;
    private int [] quantidade;
    private double [] totalFaturado;
    private int[] nrCompras;
    

    public CliProd(String c){
        this.clienteID = c;
        this.prodsMap = new HashMap<String, IProdutoDeCliente>();  
        this.quantidade = new int[12];
        this.totalFaturado = new double[12];
        this.nrCompras = new int[12];
    }

    public void addVenda(IVenda v){
        String prodID = v.getProdutoID();
        int mes = v.getMes();

        if(prodsMap.containsKey(prodID)){
            IProdutoDeCliente p = prodsMap.get(prodID);
            p.addVenda(v);
        }
        else{
            IProdutoDeCliente p = new ProdutoDeCliente(prodID);
            p.addVenda(v);
            this.prodsMap.put(prodID,p);
        }

        this.quantidade[mes-1] += v.getQuantidade();
        this.totalFaturado[mes-1] += v.getPreco()*v.getQuantidade();
        this.nrCompras[mes-1]++;

    }

    public String getClienteID(){
        return this.clienteID;
    }

    public IProdutoDeCliente getProds(String p){
        return this.prodsMap.get(p);
    }

    public int getQuantidade(int mes){
        return this.quantidade[mes-1];
    }

    public double getTotalFaturado(int mes){
        return this.totalFaturado[mes-1];
    }

    public int getNrComprasMes(int mes){
        return this.nrCompras[mes-1];
    }

    public double getTotalFaturado(){
        double total = 0;
        for(int i = 0; i < 12; i++){
            total += this.totalFaturado[i];
        }
        return total;
    }

    public boolean comprou (int mes){
        if (this.quantidade[mes-1] == 0)
            return false;
        else return true;
    }
    

    public int getNumProdutosCompradosMes(int mes){
       return (int)this.prodsMap.values().stream().filter(p -> p.comprado(mes)).count();
    } 

    public int getNumProdutosComprados(){
        return this.prodsMap.keySet().size();
    }

    public Map<String, Integer> getListaProdutosComprados(){
        Map<String, Integer> ret = new HashMap<>();
        this.prodsMap.keySet().forEach(key -> ret.put(key, prodsMap.get(key).getQuantidade()));
        return ret;
    }

    public int getQuantidadeCompradaPorCliente(String prodID){
        if (!this.prodsMap.containsKey(prodID)) return 0;
        else return this.prodsMap.get(prodID).getQuantidade(); 
    }

}