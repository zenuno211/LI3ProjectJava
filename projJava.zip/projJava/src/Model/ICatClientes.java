package Model;

import java.util.Set;

public interface ICatClientes {
    /**
     * Devolve um Set com todos os clientes
     */  
    public Set<ICliente> getClientes();

    /**
     * Metodo que dado um set, passa a sua informacao para a classe de Catclientes
     */
    public void setClientes(Set<ICliente> clientes);

    /**
     * Dado um cliente, verifica se este existe
     */
    public boolean hasCliente(ICliente c);

    /**
     * Dado o codigo de um cliente, verifica se este existe
     */
    public boolean hasCliente(String s);

    /**
     * Dado um cliente, adiciona-o à base de dados
     */
    public void addCliente(ICliente c);

    /**
     * Dado um cliente, remove-o da base de dados 
     */
    public void removeCliente(ICliente c);

    /**
     * Devolve o nummero de clientes na base de dados
     */
    public int size();

    public String toString();
    public ICatClientes clone();
    public boolean equals(Object o);
}