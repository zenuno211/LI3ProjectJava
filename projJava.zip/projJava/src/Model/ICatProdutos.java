package Model;

import java.util.Set;

public interface ICatProdutos {

    /**
     * Devolve um set de produtos
     */
    public Set<IProduto> getProdutos();
    

    /**
     * Adiciona um produto ao set de produtos dado
     */
    public void setProdutos(Set<IProduto> prods);

    /**
     * Testa se existe um dado produto
     */
    public boolean hasProduto(IProduto p);
    
    /**
     * Transforma se a String dada é um produto do catalogo
     */
    public boolean hasProduto(String s);
    
    /**
     * Adiciona um dado produto ao catalogo
     */
    public void addProduto(IProduto p);

    /**
     * Remove um dado produto do catalogo
     */
    public void removeProduto(IProduto p);
    
    /**
     * Devolve o nº de produtos existentes no catálogo
     */
    public int size();
    
    public String toString();
    public boolean equals(Object o);
    public ICatProdutos clone();
}