package Model;

import java.util.List;
import java.util.Set;

public interface IFaturacaoGlobal {

    /**
     * Devolve uma fatura de um determinado produto
     */
    public IFaturacaoP getFatura(String prodID);

    /**
     * Devolve o numero de vendas total
     */
    public int getVendasTotal();
    
    /**
     * Devolve o numero de vendas num determindao mes
     */
    public int getVendasMes(int mes);

    /**
     * Devolve o total faturado num determinado mes
     */
    public double getFaturacaoTotalMes (int mes);

    /**
     * Devolve o total faturado global
     */
    public double getFaturacaoTotal();
    
    /**
     * Adiciona uma venda 
     */
    public void addFaturaG(IVenda v);

    /**
     * Devolve o numero de vendas num determinado mes e filial
     */
    public int getTotalVendasFilialMes(int filial, int mes);
    
    /**
     * Devolve a lista X produtos mais vendidos
     */
    public List<String> getProdutosMaisVendidos(int limit);

    /**
     * Devolve o numero de vendas para um dado produto, num determinado mes 
     */
    public int getNumVendasProdutoMes(String produtoID, int mes);

    /**
     * Devolve o total faturado para um dado produto, num determinado mes 
     */
    public double getTotalFaturadoProdutoMes(String produtoID, int mes);

    /**
     * Devolve um set com os codigos de todos os produtos vendidos
     */
    public Set<String> getProdutosID();

}