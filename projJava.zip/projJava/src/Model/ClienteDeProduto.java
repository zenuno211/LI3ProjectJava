package Model;

import java.io.Serializable;

public class ClienteDeProduto implements IClienteDeProduto, Serializable{
    private static final long serialVersionUID = 4877472164986868280L;
    private int[] nrCompras;
    private int quantidade;
    private double valorGasto;

    
    public ClienteDeProduto(String clienteID){
        this.nrCompras = new int[12];
        this.quantidade = 0;
        this.valorGasto = 0;
    }

    public void addVenda(IVenda v){
        this.nrCompras[v.getMes()-1]++;
        this.quantidade += v.getQuantidade();
        this.valorGasto += v.getQuantidade() * v.getPreco();
    }


    public int getQuantidade(){
        return this.quantidade;
    }

    public double getValorGasto(){
        return this.valorGasto;
    }

    public int getNrCompras(int mes){
        return this.nrCompras[mes-1];
    }

    public boolean comprou(int mes){
        return (this.nrCompras[mes-1] > 0)? true : false;
    }
}