package Model;

import java.io.Serializable;

public class Cliente implements Comparable<ICliente>,ICliente, Serializable{
    private static final long serialVersionUID = 1225021090040745236L;
    private String id;

    public Cliente(String id){
        this.id = id;
    }

    public Cliente(Cliente c){
        this.id = c.getID();
    }

    public String getID(){
        return this.id;
    }

    public boolean isValid(){
        try{
            char letra = this.id.charAt(0);
            Integer num = Integer.parseInt(this.id.substring(1));
            return Character.isUpperCase(letra) && num >= 1000 && num <= 5000;
        } catch (NumberFormatException e){
            return false;
        }
    }
    
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Cliente: ").append(this.id).append("\n");
        return sb.toString();
    }

    public boolean equals (Object o){
        if (o == this) return true;
        if (o == null || o.getClass() != this.getClass()) return false;
        Cliente c = (Cliente) o;
        return this.id.equals(c.getID());
    }

    public ICliente clone(){
        return new Cliente(this);
    }

    @Override
    public int compareTo(ICliente c){
        return this.id.compareTo(c.getID());
    }

}