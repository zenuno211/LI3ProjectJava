package Model;

public interface IVenda {

    /**
     * Devolve o ID do produto
     */
    public String getProdutoID();
    
    /**
     * Devolve o ID do cliente
     */
    public String getClienteID();

    /**
     * Devolve a quantidade vendida (na venda em questão)
     */
    public int getQuantidade();

    /**
     * Devolve o preço unitário do produto
     */
    public double getPreco();

    /**
     * Devolve o tipo de venda
     */
    public boolean getTipo();

    /**
     * Devolve o mes da venda
     */
    public int getMes();

    /**
     * Devolve o filial onde foi realizada a venda 
     */
    public int getFilial();
    public String toString();

    /**
     * Testa se a linha da venda é válida
     */
    public boolean isValid();
    
    public boolean equals (Object o);
    public IVenda clone();
}