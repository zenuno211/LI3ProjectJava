package Model;

import java.io.Serializable;
import java.util.TreeSet;
import java.util.Set;
import Utils.Read;

public class CatClientes implements ICatClientes, Serializable{
    private static final long serialVersionUID = -7749806150901442597L;
    private Set<ICliente> clientes;

    public CatClientes(){
        this.clientes = new TreeSet<ICliente>();
    }

    public CatClientes(ICatClientes clientes){
        this.clientes = clientes.getClientes();
    }

    public CatClientes(String path){
        Set<String> clientes = Read.read(path);
        this.clientes = new TreeSet<ICliente>();
        for(String c: clientes){
            ICliente toAdd = new Cliente(c);
            this.addCliente(toAdd);
        }
    }

    public Set<ICliente> getClientes(){
        Set<ICliente> res = new TreeSet<ICliente>();
        this.clientes.forEach(c -> res.add(c.clone()));
        return res;
    }

    public void setClientes(Set<ICliente> clientes){
        clientes.forEach(c -> this.clientes.add(c.clone()));
    }

    public boolean hasCliente(ICliente c){
        return this.clientes.contains(c);
    }

    public boolean hasCliente(String s){
        Cliente c = new Cliente(s);
        return this.clientes.contains(c);
    }

    public void addCliente(ICliente c){
        if(!this.hasCliente(c) && c.isValid()) this.clientes.add(c.clone());
    }

    public void removeCliente(ICliente c){
        this.clientes.remove(c);
    }

    public int size(){
        return this.clientes.size();
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Clientes:\n").append(this.clientes);
        return sb.toString();
    }

    public ICatClientes clone(){
        return new CatClientes(this);
    }

    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass() != this.getClass()) return false;
        ICatClientes c = (CatClientes) o;
        return this.clientes.equals(c.getClientes());
    }

}