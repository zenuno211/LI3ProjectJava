package Model;

import java.util.Set;
import java.util.TreeSet;
import java.util.List;
import java.util.Map;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeMap;

public class Filiais implements IFiliais, Serializable{
    private static final long serialVersionUID = -7630732924206121714L;
    private IFilial[] filiais;

    public Filiais(){
        this.filiais = new Filial[3];
        this.filiais[0] = new Filial();
        this.filiais[1] = new Filial();
        this.filiais[2] = new Filial();
    }

    public Filiais(Set<IVenda> vendas){
        this.filiais = new Filial[3];
        this.filiais[0] = new Filial();
        this.filiais[1] = new Filial();
        this.filiais[2] = new Filial();

        vendas.forEach(v -> this.addVenda(v));
    }

    public void addVenda(IVenda v){
        this.filiais[v.getFilial()-1].addVenda(v);
    }

    public IFilial getFilial(int f){
        return this.filiais[f-1];
    }

    public List<String> getClientesCompradores(){
        List<String> clis = new ArrayList<>();
        for(int i = 0; i < 3; i++)
            this.filiais[i].getClientesCompradores().forEach(s -> {if (!clis.contains(s)) {clis.add(s);}});
        return clis;
    }

    public List<String> getClientesCompradores(String produtoID){
        List<String> clis = new ArrayList<>();
        for(int i = 0; i < 3; i++)
            this.filiais[i].getClientesCompradores(produtoID).forEach(s -> {if (!clis.contains(s)) {clis.add(s);}});
        return clis;
    }

    public int getQuantidadeCompradaPorCliente(String produtoID, String clienteID){
        int total = 0;
        for(int i = 0; i < 3; i++)
            total += this.filiais[i].getQuantidadeCompradaPorCliente(produtoID, clienteID);
        return total;
    }

    public Map<String, Double> getClientesMaisCompraram(String produtoID){
        Comparator<String> porQuantidade = (String s1, String s2) -> this.getQuantidadeCompradaPorCliente(produtoID, s2) - this.getQuantidadeCompradaPorCliente(produtoID, s1);
        Map<String, Double> clienteValorGasto = new TreeMap<String, Double>(porQuantidade);

        this.getClientesCompradores(produtoID).forEach(s -> clienteValorGasto.put(s, this.getValorGastoPorCliente(produtoID, s)));

        return clienteValorGasto;
    }

    public Double getValorGastoPorCliente(String produtoID, String clienteID){
        double total = 0;
        for(IFilial f: this.filiais){
            total += f.getValorGastoPorCliente(produtoID, clienteID);
        }
        return total;
    }

    public double getTotalFaturado(int mes, int filial){
        return this.filiais[filial-1].getFaturacaoTotalMes(mes);
    }

    public Integer getNumClientesCompradores(String prodID){
        Integer total = 0;
        for(int i = 0; i < 3; i++){
            total += this.filiais[i].getNumClientesCompradores(prodID);
        }
        return total;
    }

    public int getNumClientesCompradoresFilialMes(int filial, int mes){
        int res = 0;
        res = this.filiais[filial-1].getNumClientesCompradores(mes);
        return res;
    }

    public int getNumClientesCompradoresMes(int mes){
        Set<String> clis = new TreeSet<>();
        for(int i = 0; i < 3; i++)
            this.filiais[i].getClientesCompradores().forEach(s -> {
                                                if (!clis.contains(s)) {clis.add(s);}}
                                                );
        return clis.size();
    }

    public int getNumClientesCompradoresProdutoMes (String produtoID, int mes){
       int total = 0;
        for(int i = 0; i < 3; i++){
            total += this.filiais[i].getNumCompradores(produtoID, mes);
        }
        return total;
    }

    
    public Set<String> getProdutosComprados(){
        Set<String> ret = new TreeSet<String>();
        for(int i = 0; i < 3; i++){
            ret.addAll(this.filiais[i].getProdutosComprados());
        }
        return ret;
    }
    
    public List<String> getMaioresCompradores(int filial){
        return this.filiais[filial-1].getMaioresCompradores();
    } 

    public int getNumProdutosCompradosCliente(String clienteID, int mes){
        int total = 0;
        for(int i = 0; i<3; i++){
            total += this.filiais[i].getNumProdutosCompradosCliente(clienteID,mes);
        }
        return total;
    }
    
    public int getGastoCliente(String clienteID, int mes){
        int total = 0;
        for(int i = 0; i<3; i++){
            total += this.filiais[i].getGastoCliente(clienteID,mes);
        }
        return total;
    }
    
    public Map<String, Integer> getNumClientesCompradoresProds(List<String> prods){
        Map<String, Integer> ret = new TreeMap<String, Integer>();
        for(String s: prods){
            Integer value = this.getNumClientesCompradores(s);
            ret.put(s, value);
        }
        return ret;
    }

    public int getNrComprasMes(String clienteID, int mes){ 
        int total = 0;
        for(int i = 0; i<3; i++){
            total += this.filiais[i].getNrComprasMes(clienteID,mes);
        }
        return total;
    }

    public List<String> getListaProdutosCompradosCliente(String clienteID){
        Map<String, Integer> produtosQuantidade = new TreeMap<String, Integer>();
        List<String> ret = new ArrayList<String>();
        Comparator<String> porQuantidade = (String fp1, String fp2) -> produtosQuantidade.get(fp2) - produtosQuantidade.get(fp1);


        for(IFilial f: this.filiais){
            Map<String, Integer> toAdd = f.getListaProdutosCompradosCliente(clienteID);
            toAdd.keySet().forEach(k -> {
                if (produtosQuantidade.containsKey(k)){
                    produtosQuantidade.put(k, produtosQuantidade.get(k) + toAdd.get(k));
                } else {
                    produtosQuantidade.put(k, toAdd.get(k));
                }
            });
        };

        ret.addAll(produtosQuantidade.keySet());
        ret.sort(porQuantidade);

        return ret;

    }

    public int getNumProdutosComprados (String clienteID){
        int total = 0;
        for(int i = 0; i<3; i++){
            total += this.filiais[i].getNumProdutosComprados(clienteID);
        }
        return total;
    }


}