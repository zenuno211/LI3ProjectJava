package Model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ProdCli implements IProdCli, Serializable {
    private static final long serialVersionUID = 8574526528314277579L;
    private String prodID;
    private Map<String, IClienteDeProduto> clientMap;


    public ProdCli(String p){
        this.prodID = p;
        this.clientMap = new HashMap<String, IClienteDeProduto>();
    }

    public String getProdutoID(){
        return this.prodID;
    }

    public void addVenda(IVenda v){
        String clientID = v.getClienteID();

        if(clientMap.containsKey(clientID)){
            IClienteDeProduto c = clientMap.get(clientID);
            c.addVenda(v);
        }
        else{
            IClienteDeProduto c = new ClienteDeProduto(clientID);
            c.addVenda(v);
            this.clientMap.put(clientID,c);
        }
    }

    public IClienteDeProduto getClient(String c){
        return this.clientMap.get(c);
    }

    public int getNumClientes(){
        return this.clientMap.values().size();
    }

    public int getNumClientesCompradores(int mes){
        return (int) this.clientMap.values().stream().map(c -> c.comprou(mes)).filter(f -> f).count();
    }

    public List<String> getClientesCompradores(){
        return this.clientMap.keySet().stream().collect(Collectors.toList());
    }

    public Double getValorGasto(String clienteID){
        if (!this.clientMap.containsKey(clienteID)) return 0.0;
        else {
            return this.clientMap.get(clienteID).getValorGasto();
        }
    }


}