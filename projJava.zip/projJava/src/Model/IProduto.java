package Model;

public interface IProduto {
    
    /**
     * Devolve o ID do produto
     */
    public String getID();

    
    public String toString();
    public boolean equals (Object o);
    
    /**
     * Testa se a linha do produto é válida
     */
    public boolean isValid();
    public IProduto clone();
    public int compareTo(IProduto p);
}