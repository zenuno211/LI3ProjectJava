package Model;

import java.io.Serializable;

public class ProdutoDeCliente implements IProdutoDeCliente, Serializable{
    private static final long serialVersionUID = 1100675525437732471L;
    private int[] quantidade;  // Mês


    public ProdutoDeCliente(String prodID) {
        this.quantidade = new int[12];
    }

    public void addVenda(IVenda v){
        int mes = v.getMes();
        this.quantidade[mes-1] += v.getQuantidade();
    }

    public int getQuantidade(int mes){
        return quantidade[mes-1];
    }

    public int getQuantidade(){
        int total = 0;
        for(int q: quantidade){
            total += q;
        }
        return total;
    }

    public boolean comprado(int mes){
        if (this.quantidade[mes-1] > 0)
            return true;
        else return false;
    }

    
}