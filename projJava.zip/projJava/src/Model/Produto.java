package Model;

import java.io.Serializable;

public class Produto implements Comparable<IProduto>, IProduto, Serializable{
    private static final long serialVersionUID = -13899617855727254L;
    private String id;

    public Produto (String id){
        this.id = id;
    }

    public Produto(Produto p){
        this.id = p.getID();
    }

    public String getID(){
        return this.id;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("Produto: ").append(this.id).append("\n");
        return sb.toString();
    }

    public boolean equals (Object o){
        if (o == this) return true;
        if (o == null || o.getClass() != this.getClass()) return false;
        Produto p = (Produto) o;
        return this.id.equals(p.getID());
    }

    public boolean isValid(){
        try{
            char letra1 = this.id.charAt(0);
            char letra2 = this.id.charAt(1);

            Integer num = Integer.parseInt(this.id.substring(2));
            return Character.isUpperCase(letra1) && Character.isUpperCase(letra2) && num >= 1000 && num <= 9999;
        } catch (NumberFormatException e){
            return false;
        }
    }


    public IProduto clone(){
        return new Produto(this);
    }


    @Override
    public int compareTo(IProduto p){
        return this.id.compareTo(p.getID());
    }

}