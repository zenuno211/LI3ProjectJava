package Model;

import java.io.Serializable;

public class FaturacaoP implements IFaturacaoP, Serializable{
    private static final long serialVersionUID = -335766451591715994L;
    private String prodID;
    private int[][] nrVendas ; // Filial, Mês
    private double[][] totalFaturado; 
    private int[] quantidadeVendida; //filial


    public FaturacaoP(String prodID){
        this.prodID = prodID;
        this.nrVendas = new int[3][12];
        this.totalFaturado = new double[3][12];
        this.quantidadeVendida = new int[3]; 
    }

    
    public String getProdID(){
        return this.prodID;
    }


    public int getNrVendasFilial(int filial){
        int j, total = 0;
        for (j = 0; j < 12; j++)
            total += this.nrVendas[filial-1][j];
        return total;
    } 
    
    public int getNrVendasMes(int mes){
        int  j, total = 0;
        for (j = 0; j < 3; j++)
            total += this.nrVendas[j][mes-1];
        return total;
    }

    public int getNrVendasFilialMes(int filial, int mes){
        return this.nrVendas[filial-1][mes-1];
    }
    

    public double getTotalFaturadoFilial(int filial){
        int j;
        double total = 0;
        for (j = 0; j < 12; j++)
            total += this.totalFaturado[filial-1][j];
        return total;
    } 

    public double getTotalFaturadoMes(int mes){
        int j;
        double total = 0;
        for (j = 0; j < 3; j++)
            total += this.totalFaturado[j][mes-1];
        return total;
    }

    public double getTotalFaturadoFilialMes(int mes, int filial){
        return this.totalFaturado[filial-1][mes-1];
    }    

    public int getQuantidadeVendida(){
        int total = 0;
        for (int quant : this.quantidadeVendida)
            total += quant;
        return total;
    }
    
    public void addFatura(IVenda venda){
        int mes = venda.getMes();
        int filial = venda.getFilial();
        
        this.nrVendas[filial-1][mes-1]++;
        this.totalFaturado[filial-1][mes-1] += venda.getPreco() * venda.getQuantidade();
        this.quantidadeVendida[filial-1] += venda.getQuantidade();
    }
}