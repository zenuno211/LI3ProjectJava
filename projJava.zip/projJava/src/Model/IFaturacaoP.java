package Model;

public interface IFaturacaoP {

    /**
     * Devolve o ID de um produto
     */
    public String getProdID();

    /**
     * Devolve o nº de vendas de um produto numa dada filial
     */
    public int getNrVendasFilial(int filial);

    /**
     * Devolve o nº de vendas de um produto, numa dada filial e num dado mês
     */
    public int getNrVendasMes(int mes);

    /**
     * Devolve o nº de vendas de um produto, numa dada filial e num dado mês
     */
    public int getNrVendasFilialMes(int filial, int mes);

    /**
     * Devolve o total faturado de um produto numa dada filial
     */
    public double getTotalFaturadoFilial(int filial);

    /**
     * Devolve o total faturado de um produto num dado mês
     */
    public double getTotalFaturadoMes(int mes);

    /**
     * Devolve o total faturado de um produto, num dado mẽs e numa dada filial
     */
    public double getTotalFaturadoFilialMes(int mes, int filial);

    /**
     * Devolve a quantidade vendida de um produto
     */
    public int getQuantidadeVendida();

    /**
     * Adiciona uma fatura de um produto
     */
    public void addFatura(IVenda venda);


}