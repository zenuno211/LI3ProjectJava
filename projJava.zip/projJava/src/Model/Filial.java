    package Model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.io.Serializable;
import java.util.Comparator;
import java.util.stream.Collectors;

public class Filial implements IFilial, Serializable{
    private static final long serialVersionUID = 7001974102317093128L;
    private Map<String, ICliProd> cliProdMap;
    private Map<String, IProdCli> prodCliMap;

    public Filial(){
        this.cliProdMap = new HashMap<String, ICliProd>();
        this.prodCliMap = new HashMap<String, IProdCli>();
    }

    
    /** 
     * @param v
     */
    public void addVenda(IVenda v){
        String cliente = v.getClienteID();
        String produto = v.getProdutoID();

        if(cliProdMap.containsKey(cliente)){
            ICliProd cp = cliProdMap.get(cliente);
            cp.addVenda(v);
        }
        else {
            ICliProd cp =  new CliProd(cliente);
            cp.addVenda(v);
            this.cliProdMap.put(cliente, cp);
        }

        if(this.prodCliMap.containsKey(produto)){
            IProdCli pc = prodCliMap.get(produto);
            pc.addVenda(v);
        }
        else {
            IProdCli pc =  new ProdCli(produto);
            pc.addVenda(v);
            this.prodCliMap.put(produto, pc);
        }
    }
    
    
    /** 
     * @param mes
     * @return double
     */
    public double getFaturacaoTotalMes(int mes){
        double total = 0;
        for(ICliProd cp : cliProdMap.values())
            total += cp.getTotalFaturado(mes);
        return total;
    }

    
    /** 
     * @return Set<String>
     */
    public Set<String> getProdutosComprados(){
        return this.prodCliMap.keySet();
    }

    
    /** 
     * @param prodID
     * @return Integer
     */
    public Integer getNumClientesCompradores(String prodID){
        if(!this.prodCliMap.containsKey(prodID)) return 0;
        return this.prodCliMap.get(prodID).getNumClientes();
    }

    
    /** 
     * @param mes
     * @return int
     */
    public int getNumClientesCompradores(int mes){
        return (int) this.cliProdMap.values().stream().map(c -> c.comprou(mes)).filter(f -> f).count();
    }

    
    /** 
     * @return Set<String>
     */
    public Set<String> getClientesCompradores(){
        return this.cliProdMap.keySet();
    }
    
    
    /** 
     * @param produtoID
     * @return List<String>
     */
    public List<String> getClientesCompradores(String produtoID){
        return this.prodCliMap.get(produtoID).getClientesCompradores();
    }

    
    /** 
     * @return List<String>
     */
    public List<String> getMaioresCompradores(){
        Comparator<ICliProd> porFaturacao = (ICliProd cp1, ICliProd cp2) -> Double.compare(cp2.getTotalFaturado(), cp1.getTotalFaturado());
        List<String> ret = this.cliProdMap.values().stream().sorted(porFaturacao).limit(3).map(cl -> cl.getClienteID()).collect(Collectors.toList());
        return ret;
    }

    
    /** 
     * @param clienteID
     * @param mes
     * @return int
     */
    public int getNumProdutosCompradosCliente(String clienteID, int mes){
        return this.cliProdMap.get(clienteID).getNumProdutosCompradosMes(mes);
    }

    
    /** 
     * @param clienteID
     * @param mes
     * @return double
     */
    public double getGastoCliente(String clienteID, int mes){
        return this.cliProdMap.get(clienteID).getTotalFaturado(mes);
    }

    
    /** 
     * @param clienteID
     * @param mes
     * @return int
     */
    public int getNrComprasMes(String clienteID, int mes){
        return this.cliProdMap.get(clienteID).getNrComprasMes(mes);
    }

    
    /** 
     * @param produtoID
     * @param mes
     * @return int
     */
    public int getNumCompradores(String produtoID, int mes){
        return this.prodCliMap.get(produtoID).getNumClientesCompradores(mes);
    }

    
    /** 
     * @param clienteID
     * @return Map<String, Integer>
     */
    public Map<String, Integer> getListaProdutosCompradosCliente(String clienteID){
        return this.cliProdMap.get(clienteID).getListaProdutosComprados();
    }

    
    /** 
     * @param clienteID
     * @return int
     */
    public int getNumProdutosComprados (String clienteID){
        return this.cliProdMap.get(clienteID).getNumProdutosComprados();
    }
    
    
    /** 
     * @param produtoID
     * @param clienteID
     * @return int
     */
    public int getQuantidadeCompradaPorCliente(String produtoID, String clienteID){
        return this.cliProdMap.get(clienteID).getQuantidadeCompradaPorCliente(produtoID);
    }

    
    /** 
     * @param produtoID
     * @param clienteID
     * @return Double
     */
    public Double getValorGastoPorCliente(String produtoID, String clienteID){
        return this.prodCliMap.get(produtoID).getValorGasto(clienteID);
    }
}