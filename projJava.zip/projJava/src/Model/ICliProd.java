package Model;

import java.util.Map;

public interface ICliProd {

    /**
     * Devolve o codigo do cliente, para a qual está associada a classe cliprod
     */
    public String getClienteID();

    /**
     * Adiciona uma venda, associada a esse cliente
     */
    public void addVenda(IVenda v);

    /**
     *Devolve uma classe prods associada a um dado produto 
     */
    public IProdutoDeCliente getProds(String p);

    /**
     * Devolve a quantidade comprada pelo cliente num dado mes
     */
    public int getQuantidade(int mes);

    /**
     * Devolve o total faturado com o cliente, num dado mes
     */
    public double getTotalFaturado(int mes);

    /**
     * Devolve o numero de compras efetudadas pelo cliente, num dado mes
     */
    public int getNrComprasMes(int mes);

    /**
     * Verifica se o cliente realizou compras, num determinado mes
     */
    public boolean comprou (int mes);

    /**
     * Devolve o total faturado com o cliente
     */
    public double getTotalFaturado();

    /**
     * devolve o numero de produtos comprados pelo cliente num determinado mes
     */
    public int getNumProdutosCompradosMes(int mes);

    /**
     * Devolve um Map que relaciona os produtos comprados com a quantidade adquirida dos mesmos 
     */
    public Map<String, Integer> getListaProdutosComprados();

    /**
     * Devolve o numero total de produtos comprados pelo cliente
     */
    public int getNumProdutosComprados();

    /**
     * Devolve a quantidade comprada de um dado produto, pelo cliente
     */
    public int getQuantidadeCompradaPorCliente(String prodID);
}