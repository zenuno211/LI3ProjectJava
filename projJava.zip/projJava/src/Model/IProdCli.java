package Model;

import java.util.List;

public interface IProdCli {

    /**
     * Retorna ID do produto
     */
    public String getProdutoID();

    /**
     * Adiciona uma venda a uma prodcli
     */
    public void addVenda(IVenda v);

    /**
     * Dado o codigo de um cliente devolve o cliente pretendido
     */
    public IClienteDeProduto getClient(String c);

    /**
     * Devolve o numero de clientes de uma prodcli
     */
    public int getNumClientes();

    /**
     * Devolve o numero de clientes que efetuaram compras para o produto para o qual está a associada a prodcli 
     */
    public int getNumClientesCompradores(int mes);

    /**
     * Devolve a lista dos codigos de clientes que efetuaram compras para o produto para o qual está a associada a prodcli 
     */
    public List<String> getClientesCompradores();

    /**
     * Devolve o valor total gasto por um dado cliente na compra do produto para o qual está associada a prodcli
     */
    public Double getValorGasto(String clienteID);
}