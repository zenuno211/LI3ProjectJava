package Model;

import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;
import Utils.Read;

public class CatProdutos implements ICatProdutos, Serializable{
    private static final long serialVersionUID = -1970428430442401935L;
    private Set<IProduto> produtos;

    public CatProdutos() {
        this.produtos = new TreeSet<IProduto>();
    }

    public CatProdutos(ICatProdutos prods) {
        this.produtos = prods.getProdutos();
    }

    public CatProdutos(String path){
        Set<String> produtos = Read.read(path);
        this.produtos = new TreeSet<IProduto>();
        for(String p: produtos){
            IProduto toAdd = new Produto(p);
            this.addProduto(toAdd);
        }
    }

    public Set<IProduto> getProdutos() {
        Set<IProduto> res = new TreeSet<>();
        this.produtos.forEach(p -> res.add(p.clone()));
        return res;
    }

    public void setProdutos(Set<IProduto> prods) {
        prods.forEach(p -> this.produtos.add(p.clone()));
    }

    public boolean hasProduto(IProduto p) {
        return this.produtos.contains(p);
    }

    public boolean hasProduto(String s) {
        Produto p = new Produto(s);
        return this.produtos.contains(p);
    }

    public void addProduto(IProduto p) {
        if (!this.hasProduto(p) && p.isValid())
            this.produtos.add(p.clone());
    }

    public void removeProduto(IProduto p) {
        this.produtos.remove(p);
    }

    public int size() {
        return this.produtos.size();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CatProdutos:\n").append(this.produtos);
        return sb.toString();
    }

    public ICatProdutos clone() {
        return new CatProdutos(this);
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (o == null || o.getClass() != this.getClass())
            return false;
        ICatProdutos p = (CatProdutos) o;
        return this.produtos.equals(p.getProdutos());
    }

}