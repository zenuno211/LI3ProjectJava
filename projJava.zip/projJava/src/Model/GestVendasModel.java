package Model;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.*;

import Exceptions.*;

import java.util.Map;
import Utils.Read;

public class GestVendasModel implements IGestVendasModel, Serializable{
    private static final long serialVersionUID = 5380583330226043376L;
    private ICatClientes catClientes;
    private ICatProdutos catProdutos;
    private IFiliais filiais;
    private IFaturacaoGlobal faturacaoGlobal;
    private Set<IVenda> vendas;
    private int vendasValidas;
    private int vendasLidas;
    private String file;

    public GestVendasModel(String path){
        this.file = path;
        this.catClientes = new CatClientes("input_files/Clientes.txt");
        this.catProdutos = new CatProdutos("input_files/Produtos.txt");

        this.vendas = Read.readVendas(path, catClientes, catProdutos);
        this.vendasLidas = vendas.size();

        vendas.removeIf(v -> !v.isValid() || !catClientes.hasCliente(v.getClienteID()) || !catProdutos.hasProduto(v.getProdutoID()));
        this.vendasValidas = vendas.size();

        this.filiais = new Filiais(vendas);
        this.faturacaoGlobal = new FaturacaoGlobal(vendas);
    }

    public GestVendasModel(){
        this.file = "";
        this.catClientes = new CatClientes();
        this.catProdutos = new CatProdutos();

        this.vendas = new TreeSet<>();
        this.vendasLidas = 0;

        this.vendasValidas = 0;

        this.filiais = new Filiais();
        this.faturacaoGlobal = new FaturacaoGlobal();
    }

    public boolean hasProduto(String produtoID){
        return this.catProdutos.hasProduto(produtoID);
    }    

    public String getFile(){
        return this.file;
    }

    //Querie estatistica

    public int getVendasInvalidas(){
        return this.vendasLidas - this.vendasValidas;
    }

    public int getVendasValidas(){
        return this.vendasValidas;
    }

    public int getVendasLidas(){
        return this.vendasLidas;
    }

    public int getTotalProdutos(){
        return this.catProdutos.size();
    }

    public int getTotalProdutosComprados(){
        return (int) this.vendas.stream().map(IVenda::getProdutoID).distinct().count(); 
    }
    
    public int getTotalProdutosNaoComprados(){
        return this.catProdutos.size() - this.getTotalProdutosComprados();
    }

    public int getTotalClientes(){
        return this.catClientes.size();
    }

    public int getTotalClientesCompradores(){
        return (int) this.vendas.stream().map(IVenda::getClienteID).distinct().count();
    }

    public int getTotalClientesNaoCompradores(){
        return this.getTotalClientes() - this.getTotalClientesCompradores();
    }

    public long getTotalComprasZero(){
        return this.vendas.stream().filter(v -> (v.getPreco() == 0.0)).count();
    }

    public double getFaturacaoTotal(){
        return this.faturacaoGlobal.getFaturacaoTotal();
    }

    public IStatsVenda getStatsVenda(){
        String fileName = this.file;
        int vendasErradas = this.getVendasInvalidas();
        int vendasZero = (int) this.getTotalComprasZero();
        int produtos = this.getTotalProdutos();
        int produtosComprados = this.getTotalProdutosComprados();
        int produtosNaoComprados = this.getTotalProdutosNaoComprados();
        int clientes = this.getTotalClientes();
        int clientesCompram = this.getTotalClientesCompradores();
        int clientesNaoCompram = this.getTotalClientesNaoCompradores();
        double faturacaoTotal = this.getFaturacaoTotal();
        return new StatsVenda(fileName, vendasErradas, vendasZero, produtos, produtosComprados, produtosNaoComprados, clientes, clientesCompram, clientesNaoCompram, faturacaoTotal);
    }

    /* Estatistica - Faturação por mes (filial) */
    public double[] getFaturacaoTotalFilialMes(int filial){
        double[] fatFilial = new double[12];
        for(int i = 0; i < 12; i++){
            fatFilial[i] = this.filiais.getTotalFaturado(i+1, filial);
        }
        return fatFilial;
    }

    public double[][] getFaturacaoTotalFilialMes(){
        double[][] fat = new double[3][12];
        for(int i = 0; i < 3; i++){
            fat[i] = this.getFaturacaoTotalFilialMes(i+1);
        }
        return fat;
    }

    /* Estatística - Total de compras (mes) */
    public int[] getNumTotalComprasMes(){
        int[] comprasMes = new int[12];
        for(int i = 0; i < 12; i++){
            comprasMes[i] = this.faturacaoGlobal.getVendasMes(i+1);
        }
        return comprasMes;
    }

    /* Estatistica - nº de clientes */
    public int[][] getNumClientesCompradoresFilialMes(){
        int[][] numCli = new int[3][12];
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 12; j++){
                numCli[i][j] = this.filiais.getNumClientesCompradoresFilialMes(i+1, j+1);
            }
        }
        return numCli;
    }


    // QUERIES -------------------------------------------------------------------------------------------------------------------------

    /* Query 1 */
    public List<String> getListaProdutosNuncaComprados(){

        List<String> total = this.catProdutos.getProdutos().stream().map(p -> p.getID()).sorted().collect(Collectors.toList());
        Set<String> comprados = this.filiais.getProdutosComprados();
        total.removeAll(comprados);

        return total;
    }


     /* Query 2 P1*/
     public int getTotalVendasMes(int mes) throws MesInvalidoException{
        if(mes < 1 || mes > 12){
            throw new MesInvalidoException();
        }
        return this.faturacaoGlobal.getVendasMes(mes);
    }
    
    
    /* Query 2 P2*/
    
    public int[] getTotalVendasPorFilialMes(int mes) throws MesInvalidoException{
        if(mes < 1 || mes > 12){
            throw new MesInvalidoException();
        }
        int[] res = new int[3];
        for(int filial = 1; filial < 4; filial++)
            res[filial-1] = this.faturacaoGlobal.getTotalVendasFilialMes(filial, mes);

        return res;
    }

    /* Query 2 P3 */
    public int getNumCompradoresMes(int mes) throws MesInvalidoException{
        if(mes < 1 || mes > 12){
            throw new MesInvalidoException();
        }
        return this.filiais.getNumClientesCompradoresMes(mes);
    }

    /* Query 2 P4*/

    public int[] getNumClientesCompradoresPorFilialMes(int mes) throws MesInvalidoException{
        if(mes < 1 || mes > 12){
            throw new MesInvalidoException();
        }
        int res[] = new int[3];
        for(int filial = 1; filial < 4; filial++)
            res[filial-1] = this.filiais.getNumClientesCompradoresFilialMes(filial, mes);
        return res;
    }


    /* Query 3 */ 


    public int[] getNumProdutosCompradosCliente(String clienteID) throws ClienteInvalidoException { 
        if(!this.catClientes.hasCliente(clienteID)){
            throw new ClienteInvalidoException();
        }
        int[] numProdutosComprados = new int[12];
        for(int i = 0; i < 12; i++){
            numProdutosComprados[i] = this.filiais.getNumProdutosCompradosCliente(clienteID,i+1);
        }
        return numProdutosComprados;
    }

    public double[] getGastoCliente (String clienteID) throws ClienteInvalidoException{ 
        if(!this.catClientes.hasCliente(clienteID)){
            throw new ClienteInvalidoException();
        }
        double[] gasto = new double[12];
        for(int i = 0; i < 12; i++){
            gasto[i] = this.filiais.getGastoCliente(clienteID,i+1);
        }
        return gasto;
    }

    public int[] getNrComprasMes(String clienteID) throws ClienteInvalidoException{
        if(!this.catClientes.hasCliente(clienteID)){
            throw new ClienteInvalidoException();
        }
        int[] numCompras = new int[12];
        for(int i = 0; i < 12; i++){
            numCompras[i] = this.filiais.getNrComprasMes(clienteID,i+1);
        }
        return numCompras;
    }

    

    /* Query 4 */  
    public int[] getNumVendasProdutoMes(String produtoID) throws ProdutoInvalidoException{
        if(!this.catProdutos.hasProduto(produtoID)){
            throw new ProdutoInvalidoException();
        }
        int[] numVendas = new int[12];
        for(int i = 0; i < 12; i++){
            numVendas[i] = this.faturacaoGlobal.getNumVendasProdutoMes(produtoID, i+1);
        }
        return numVendas;
    }

    public double[] getTotalFaturadoProdutoMes(String produtoID) throws ProdutoInvalidoException{
        if(!this.catProdutos.hasProduto(produtoID)){
            throw new ProdutoInvalidoException();
        }
        double[] totalFaturado = new double[12];
        for(int i = 0; i < 12; i++){
            totalFaturado[i] = this.faturacaoGlobal.getTotalFaturadoProdutoMes(produtoID, i+1);
        }
        return totalFaturado;   
    }

    public int[] getNumClientesCompradoresProdutoMes(String produtoID) throws ProdutoInvalidoException{
        if(!this.catProdutos.hasProduto(produtoID)){
            throw new ProdutoInvalidoException();
        }
        int[] nrCompradores = new int[12];
        for(int i = 0; i < 12; i++){
            nrCompradores[i] = this.filiais.getNumClientesCompradoresProdutoMes(produtoID, i+1);
        }
        return nrCompradores;
    }

   

    /* Query 5 
    produtos que cliID mais comprou, e quantos , ordenada por ordem descrescente de quantiade e para quantidades iguais, ordem alfabetica*/
    public List<String> getListaProdutosCompradosCliente(String clienteID) throws ClienteInvalidoException{
        if(!this.catClientes.hasCliente(clienteID)){
            throw new ClienteInvalidoException();
        }
        List<String> ret = this.filiais.getListaProdutosCompradosCliente(clienteID);
        return ret;
    }


    /* Query 6 Lista certa, Ordem errada*/
    public Map<String, Integer> getProdutosMaisVendidos(int limit) throws LimiteInvalidoException{
        if(limit < 0) throw new LimiteInvalidoException();
        List<String> prods = this.faturacaoGlobal.getProdutosMaisVendidos(limit);
        Map<String, Integer> ret = this.filiais.getNumClientesCompradoresProds(prods);
        return ret;
    }


    /* Query 7 
    Clientes mais compradores em total faturado*/
    public List<String> getMaioresCompradores(int filial){
        return this.filiais.getMaioresCompradores(filial);
    }

    /* Query 8 
    X clientes que compraram mais produtos diferentes e quantos, ordem decrs de nº de produtos*/
    public Map<String,Integer> getMaisCompradores(int limit) throws LimiteInvalidoException{
        if(limit < 0) throw new LimiteInvalidoException();
        Comparator<String> porQuantidadeProds = (String s1, String s2) -> {
            int r = this.filiais.getNumProdutosComprados(s2) - this.filiais.getNumProdutosComprados(s1);
            if(r == 0) return s1.compareTo(s2);
            else return r;
        };

        Set<ICliente> clisC = this.catClientes.getClientes();
        Set<String> clis = clisC.stream().map(c -> c.getID()).collect(Collectors.toSet());

        
        Map<String, Integer> ret = new TreeMap<String, Integer>(porQuantidadeProds);

        clis.stream().sorted(porQuantidadeProds).limit(limit).collect(Collectors.toSet()).forEach(s -> ret.put(s, this.filiais.getNumProdutosComprados(s)));

        return ret;
    }


    /* Query 9 
    clientes que mais comprararam prod*to (ordenado por quantidade) e para cada valor gasto*/
    public Map<String, Double> getClientesMaisCompraram(String produtoID) throws ProdutoInvalidoException{
        if(!this.catProdutos.hasProduto(produtoID)){
            throw new ProdutoInvalidoException();
        }
        return this.filiais.getClientesMaisCompraram(produtoID);
    }

    /* Query 10  */
    
    public double[][] getFaturacaoTotalPorProduto(String prodID) {
        double[][] res = new double[3][12];
        IFaturacaoP fatP = this.faturacaoGlobal.getFatura(prodID);
        for(int filial = 1; filial < 4; filial++)
            for(int mes = 1; mes < 13; mes++)
                res[filial-1][mes-1] += fatP.getTotalFaturadoFilialMes(mes, filial);
        return res;
    } 
    
    public Map<String, double[][]> getFaturacaoTotalPorProduto(){
        Set<String> produtos = this.faturacaoGlobal.getProdutosID();
        Map<String, double[][]> res = new TreeMap<>();
        produtos.forEach(p -> res.put(p,this.getFaturacaoTotalPorProduto(p)));
        return res;

    }


    public void save(String fileName) throws IOException{
        ObjectOutputStream os = new ObjectOutputStream( new FileOutputStream(fileName));
        os.writeObject(this);
        os.close();
    }
    
    public GestVendasModel load(String fileName) throws IOException, ClassNotFoundException{
        ObjectInputStream is = new ObjectInputStream(new FileInputStream(fileName));
        GestVendasModel model = (GestVendasModel) is.readObject();
        is.close();
        return model;
    }
    
    
}   