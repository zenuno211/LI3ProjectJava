package Model;

public interface ICliente {  
    
    /**
     * Devolve o ID do cliente
     */
    public String getID();
    
    /**
     * Testa se a linha do cliente é válida
     */
    public boolean isValid();

    public String toString();
    public boolean equals (Object o);
    public ICliente clone();
    public int compareTo(ICliente c);
}