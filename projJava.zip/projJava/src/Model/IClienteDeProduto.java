package Model;

public interface IClienteDeProduto {

    /**
     * Adiciona uma venda a uma filial
     */
    public void addVenda(IVenda v);

    /**
     * Devolve a quantidade comprada pelo cliente 
     */
    public int getQuantidade();

    /**
     * Devolve o total gasto por esse cliente 
     */
    public double getValorGasto();

    /**
     * Devolve o numero de compras realizada pelo cliente num dado mes
     */
    public int getNrCompras(int mes);

    /**
     * Verifica se o cliente fez compras num dado mes 
     */
    public boolean comprou(int mes);
}