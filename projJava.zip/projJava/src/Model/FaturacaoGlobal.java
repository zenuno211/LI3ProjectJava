package Model;

import java.io.Serializable;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class FaturacaoGlobal implements IFaturacaoGlobal, Serializable{
    private static final long serialVersionUID = 835228351868568069L;
    private Map <String, IFaturacaoP> faturas;
    private double [] faturacaoTotal; // meses 
    private int [] vendasTotal; // meses

    public FaturacaoGlobal(){
        this.faturas = new HashMap<>();
        this.faturacaoTotal = new double[12];
        this.vendasTotal = new int[12];

    }

    public FaturacaoGlobal(Set<IVenda> vendas){
        this.faturas = new HashMap<>();
        this.faturacaoTotal = new double[12];
        this.vendasTotal = new int[12];
        
        vendas.forEach(v -> this.addFaturaG(v));
    }

    public IFaturacaoP getFatura(String prodID){
        if(this.faturas.containsKey(prodID)){
            return this.faturas.get(prodID);
        } else return null;

    }
    
    public int getVendasTotal(){
        int sum = 0, i;
        for(i = 0; i < 12; i++){
            sum += this.vendasTotal[i];
        }
        return sum;
    }
    
    public int getVendasMes(int mes){
        return this.vendasTotal[mes-1];
    }

    public int getNumVendasProdutoMes(String produtoID, int mes){
        if(!this.faturas.containsKey(produtoID)){
            System.out.println(produtoID + " not found");
            return 0;
        }
        return this.faturas.get(produtoID).getNrVendasMes(mes);
    }
    
    public double getFaturacaoTotalMes (int mes){
        return this.faturacaoTotal[mes-1];      
    }

    public double getFaturacaoTotal(){
        double total = 0;
        for(double fat : this.faturacaoTotal)
            total += fat;
        return total;
    }
    
    public void addFaturaG(IVenda v){
        String prodID = v.getProdutoID();
        if(this.faturas.containsKey(prodID)){
            IFaturacaoP fatP = this.faturas.get(prodID);
            fatP.addFatura(v);
        } else {
            IFaturacaoP fatP = new FaturacaoP(prodID);
            fatP.addFatura(v);
            this.faturas.put(prodID, fatP);
        }
        this.faturacaoTotal[v.getMes()-1] += v.getQuantidade() * v.getPreco();
        this.vendasTotal[v.getMes()-1] ++;
    }

    public double getTotalFaturadoProdutoMes(String produtoID, int mes){
        if(!this.faturas.containsKey(produtoID)) return 0;
        return this.faturas.get(produtoID).getTotalFaturadoMes(mes);
    }


    public int getTotalVendasFilialMes(int filial, int mes){
        return this.faturas.values().stream().mapToInt(f-> f.getNrVendasFilialMes(filial, mes)).sum();
    }
    
    public List<String> getProdutosMaisVendidos(int limit){
        Comparator<IFaturacaoP> porUnidades = (IFaturacaoP fp1, IFaturacaoP fp2) -> fp2.getQuantidadeVendida() - fp1.getQuantidadeVendida();
        return this.faturas.values().stream().sorted(porUnidades).limit(limit).map(fp -> fp.getProdID()).collect(Collectors.toList());
    }


    public Set<String> getProdutosID(){
        return this.faturas.keySet();
    
    }


}
