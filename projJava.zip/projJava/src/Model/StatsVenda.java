package Model;

public class StatsVenda implements IStatsVenda {
    private String file;
    private int vendasErradas;
    private int vendasZero;
    private int produtos;
    private int produtosComprados;
    private int produtosNaoComprados;
    private int clientes;
    private int clientesCompram;
    private int clientesNaoCompram;
    private double faturacaoTotal;
     

   public StatsVenda(String file, int vendasErradas, int vendasZero, 
                        int produtos, int produtosComprados, int produtosNaoComprados, int clientes,
                        int clientesCompram, int clientesNaoCompram, double faturacaoTotal) {
       this.file = file;
       this.vendasErradas = vendasErradas;
       this.vendasZero = vendasZero;
       this.produtos = produtos;
       this.produtosComprados = produtosComprados;
       this.produtosNaoComprados = produtosNaoComprados;
       this.clientes = clientes;
       this.clientesCompram = clientesCompram;
       this.clientesNaoCompram = clientesNaoCompram;
       this.faturacaoTotal = faturacaoTotal;
   }
    

    public String getFile(){
        return this.file;
    }
    
    public int getVendasErradas(){
        return this.vendasErradas;
    }
    
    public int getVendasZero(){
        return this.vendasZero;
    }

    public int getProdutos(){
        return this.produtos;
    }
    
    public int getProdutosComprados(){
        return this.produtosComprados;
    }
   
    public int getProdutosNaoComprados(){
        return this.produtosNaoComprados;
    }

    public int getClientes(){
        return this.clientes;
    }

    public int getClientesNaoCompram(){
        return this.clientesNaoCompram;
    }

    public int getClientesCompram(){
        return this.clientesCompram;
    }

    public double getFaturacaoTotal(){
        return this.faturacaoTotal;
    }

    
}