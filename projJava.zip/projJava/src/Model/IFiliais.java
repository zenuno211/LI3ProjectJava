package Model;

import java.util.Set;
import java.util.List;
import java.util.Map;

public interface IFiliais {

    /**
     * Adiciona uma venda aos filiais
     */
    public void addVenda(IVenda v);

    /**
     * Devolve o filial pretendido
     */
    public IFilial getFilial(int f);

    /**
     * Devolve o total faturado para um dado mes e filial
     */
    public double getTotalFaturado(int mes, int filial);

    /**
     * Devolve uma lista de todos os clientes que realizaram compras
     */
    public List<String> getClientesCompradores();

    /**
     * Devolve a quantidade comprada por um dado cliente, de um dado produto
     */
    public int getQuantidadeCompradaPorCliente(String produtoID, String clienteID);

    /**
     * Devolve um Map que associa os clientes que compraram um dado produto ao gasto dos mesmos na sua compra 
     */
    public Map<String, Double> getClientesMaisCompraram(String produtoID);

    /**
     * Devolve o numero de clientes que compraram um dado produto
     */
    public Integer getNumClientesCompradores(String prodID);

    /**
     * Devolve o numero de clientes que compraram um dado produto num determinado mes
     */
    public int getNumClientesCompradoresProdutoMes (String produtoID, int mes);

    /**
     * Devolve o numero de clientes que realizaram compras num determinado filial e num dado mes
     */
    public int getNumClientesCompradoresFilialMes(int filial, int mes);

    /**
     * Devolve o numero de clientes que realizaram compras num dado mes
     */
    public int getNumClientesCompradoresMes(int mes);

    /**
     * Devolve um set com o coddigo de todos os produtos comprados
     */
    public Set<String> getProdutosComprados();

    /**
     * Devolve a lista dos maiores compradores dado um filial
     */
    public List<String> getMaioresCompradores(int filial);

    /**
     * Devolve o numero de Produtos comprados por um dado cliente, num determinado mes
     */
    public int getNumProdutosCompradosCliente(String clienteID, int mes);

    /**
     * Devolve o gasto de um dado cliente num determinado mes 
     */
    public int getGastoCliente(String clienteID, int mes);

    /**
     * Devolve um Map que associa a um produto o numero de clientes que o compraram
     */
    public Map<String, Integer> getNumClientesCompradoresProds(List<String> prods);

    /**
     * Devolve a lista (ordenada por quantidade) de todos os produtos comprados por um dado cliente
     */
    public List<String> getListaProdutosCompradosCliente(String clienteID);

    /**
     * Devolve o numero de compras efetuadas por um dado cliente num determinado mes
     */
    public int getNrComprasMes(String clienteID, int mes);

    /**
     * Devolve o numero de produtos comprados por um dado cliente
     */
    public int getNumProdutosComprados (String clienteID);

    /**
     * Devolve o total gasto por um determinado cliente na compra de um produto  
     */
    public Double getValorGastoPorCliente(String produtoID, String clienteID);
}