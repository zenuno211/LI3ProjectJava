package Exceptions;

public class MesInvalidoException extends Exception{
    public MesInvalidoException(){
        super();
    }
}