package Exceptions;

public class FilialInvalidaException extends Exception{
    public FilialInvalidaException(){
        super();
    }
}