package Exceptions;

public class ProdutoInvalidoException extends Exception{
    public ProdutoInvalidoException(){
        super();
    }
}