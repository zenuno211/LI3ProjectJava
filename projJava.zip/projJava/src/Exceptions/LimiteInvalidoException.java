package Exceptions;

public class LimiteInvalidoException extends Exception {
    public LimiteInvalidoException(){
        super();
    }
}