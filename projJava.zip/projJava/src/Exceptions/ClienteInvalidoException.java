package Exceptions;

public class ClienteInvalidoException extends Exception{
    public ClienteInvalidoException(){
        super();
    }
}