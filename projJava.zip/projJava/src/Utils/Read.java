package Utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Function;
import java.util.stream.Collectors;

import Model.*;

public class Read{

    public static Set<String> read(String file){
        BufferedReader br = null;
        String line = null;
        Set<String> res = new TreeSet<String>();


        try{
            br = new BufferedReader(new FileReader(file));
            line = br.readLine();

            while(line != null){
                res.add(line);
                line = br.readLine();
            }
        }
        catch(IOException e){
            System.out.println(e);
        }

        return res;
    }

    public static Set<IVenda> readVendas(String file, ICatClientes clis, ICatProdutos prods){
        Function<String, String[]> tokenize = str -> str.split(" ");
        Function<String[], IVenda> toSale = fields -> new Venda(fields[0],
                                                            fields[4],
                                                            Integer.parseInt(fields[2]),
                                                            Double.parseDouble(fields[1]),
                                                            fields[3].charAt(0) == 'P',
                                                            Integer.parseInt(fields[5]),
                                                            Integer.parseInt(fields[6]));


        Set<IVenda> vendas = new TreeSet<>();
        try{
            vendas = Files.lines(Paths.get(file))
                                            .map(tokenize)
                                            .map(toSale)
                                            .collect(Collectors.toSet());
        } catch(IOException e){
            System.out.println("Erro ler vendas" + e);
        }

        return vendas;
    }
    
}