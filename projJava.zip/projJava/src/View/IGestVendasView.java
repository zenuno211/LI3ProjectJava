package View;

import java.util.List;
import java.util.Map;
import Model.IStatsVenda;

public interface IGestVendasView {
    /**
     * Limpa o ecrã
     */
    public void clearScreen();

    /**
     * Imprime o titulo da aplicacao 
     */
    public void showTitle();

    /**
     * Dá print ao menu inicial, onde o utilizador pode escolher o que deseja ver
     */
    public void showMenu();

    /**
     * Dá print a uma mensagem que pede ao utilizador para inserir um certo valor
     */    
    public void showGet(String toGet);
    
    /**
     * Dá print a uma mensagem quando o utilizador sai da aplicação
     */
    public void showExitMessage();
    
    /**
     * Dá print a uma mensagem para o utilizador saber que tecla tem de usar para voltar atrás na aplicação
     */
    public void showQuit();
    
    /**
     * Dá print de uma mensagem de erro
     */
    public void showErro(String errado);
    
    /**
     * Dá print de uma mensagem de erro (Opção inválida)
     */
    public void showErroOpcao();
    
    /**
     * Imprime uma mensagem de orientacao
     */
    public void showENTERReturn();
    
    /**
     * Imprime uma mensagem de orientacao
     */
    public void showENTER();

    /**
     * Imprime um dado tempo
     */
    public void showTime(String time);

    /**
     * Imprime os ficheiros possiveis que se podem carregar
     */
    public void chooseVenda(String fileName, boolean showNotFound);
    
    /**
     * Imprime uma mensagem de ficheiro a guardar 
     */
    public void saving();

    /**
     * Imprime uma mensagem de ficheiro guardado
     */
    public void saved(String fileName);
    
    /**
     * Imprime uma mensagem de carregamento
     */
    public void loading();

    /**
     * Imprime uma mensagem de carregamento efetuado
     */
    public void loaded(String fileName);
    
    /**
     * Usada na paginacao relacionada com listas
     */
    public void showPageLista(String titulo, List<String> lista, int page, int pageSize, int numPages, int listSize);
    
    /**
     * Usada na paginacao relacionada com maps
     */
    public void showPageMap(String titulo, Map<String, ? extends Number> map, int page, int pageSize, int numPages, int listSize);

    /**
     * Imprime os dados estatisticos do ficheiro carregado
     */
    public void showStatsVenda(IStatsVenda sv);

    /**
     * Ligação entre utilizador e query estatistica
     */
    public void showStats1( int[] compras, double[][] totalFaturado, int[][] numClientes, double fatTotal);

    /**
     * Ligação entre utilizador e query 2
     */
    public void showQ2(int totvendas, int[] totvendasF,int totcompradores,int[]totcompradoresF, int mes);
   
    /**
     * Ligação entre utilizador e query 3
     */
    public void showQ3(int[] prodsComprados, double[] gasto, int[] nrCompras,String ClienteID);
    
    /**
     * Ligação entre utilizador e query 4
     */
    public void showQ4(int[] nrVendas, double[] totalfaturado, int[] nrClientes, String produtoID);
    
    /**
     * Ligação entre utilizador e query 7
     */
    public void showQ7(List<List<String>> compradores);
    
    /**
     * Ligação entre utilizador e query 10
     */
    public void showQ10(String produtoID, double[][] fat);
    
}