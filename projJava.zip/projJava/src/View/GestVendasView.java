package View;

import Model.IStatsVenda;

import java.util.Map;
import java.util.Set;
import java.util.List;
import java.text.DecimalFormat;

public class GestVendasView implements IGestVendasView {
    private boolean run;

    
    public GestVendasView(){
        this.run = true;
    }

    public boolean getRun(){
        return this.run;
    }

    public void setRun(){
        this.run = false;
    }
    
    public void clearScreen() {  
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }  

    /* void clearScreen(){
        Runtime.exec("clear");
    } */
    
    public void showTitle(){
        clearScreen();
        System.out.println("\n-----------------------------\n");
        System.out.println("\n      GESTOR DE VENDAS\n");
        System.out.println("\n-----------------------------\n");
    }
    
     
    public void showStart(){
        showTitle();
        System.out.println("\nQue ficheiros deseja tratar?");
        System.out.println("1 - Carregar ficheiros predefinidos");
        System.out.println("2 - Carregar ficheiros personalizados");
        System.out.println("3 - Sair\n");
        System.out.println("Selecione uma opção: ");
    }
    
    
    public void showMenu(){
        showTitle();
        
        System.out.println("0 - Dados estatísticos");
        System.out.println("1 - Lista de produtos nunca comprados e respetivo total (Q1)");
        System.out.println("2 - Número de vendas realizadas e clientes distintos que as fizeram, num mês e filial a filial (Q2)");
        System.out.println("3 - Número de compras e de produtos comprados de um cliente e respetivo gasto, para cada mês (Q3)");
        System.out.println("4 - Número de vendas e de clientes de um produto, e respetivo total faturado (Q4)");
        System.out.println("5 - Lista de produtos que um cliente comprou e respetivo número (Q5)");
        System.out.println("6 - Conjunto de produtos mais vendidos em todo ano (unidades vendidas) e o número total de clientes que os compraram (Q6)");
        System.out.println("7 - Lista dos 3 maiores compradores (dinheiro faturado) para cada filial (Q7)");
        System.out.println("8 - Conjunto clientes que compraram mais produtos diferentes e quantos compraram (Q8)");
        System.out.println("9 - Conjunto de clientes que mais compraram um certo produto, e quanto gastaram (Q9)");
        System.out.println("10 - Faturação total com cada produto, mês a mês e filial a filial (Q10)");

        System.out.println("S - Guardar para ficheiro binário");
        System.out.println("L - Carregar o ficheiro binário");
        System.out.println("T - Carregar ficheiro de vendas");

        System.out.println("Q - Sair\n");
        System.out.print("Selecione uma opção: ");    
    }
        

    public void showGet(String toGet){
        System.out.print("Insira um" + toGet +": ");
    }
/*
    public void showGetFilial(String Filial){
        System.out.print("Insira uma filial: ");
        System.out.println("0 -> Todas as filiais");
        System.out.println("[1 - 3] -> Filiais individualmente");
    }
    */
    public void showExitMessage(){
        System.out.println("Execução terminada\n");
    }

    public void showQuit(){
        System.out.println("\nInsira Q para retornar");
    }

    public void showErro(String errado){
        System.out.println("\nO " + errado + " inserido não é válido");
        showENTERReturn();
    }

    public void showErroOpcao(){
        System.out.println("\nOpção Inválida!");
        showENTERReturn();
    }

    public void showENTERReturn(){
        System.out.println("Pressione ENTER para retornar");
    }

    public void showENTER(){
        System.out.println("Pressione ENTER para continuar");
    }

    public void showTime(String time){
        showTitle();
        System.out.println("Tempo demorado: " + time + " segundos");
        showENTER();
    }

    public void chooseVenda(String fileName, boolean showNotFound){
        showTitle(); 
        if(showNotFound) System.out.println("Ficheiro " + fileName + " não encontrado\n");
        System.out.println("1 - Vendas_1M.txt");
        System.out.println("2 - Vendas_3M.txt");
        System.out.println("3 - Vendas_5M.txt");
        if(!showNotFound) System.out.println("Q - Retornar");
        System.out.println("");
        System.out.print("Escolha ficheiro que quer carregar:");    
    }



    public void saving(){
        System.out.println("A gravar...");
    }

    public void saved(String fileName){
        System.out.println("Ficheiro " + fileName + " gravado");
    }

    public void loading(){
        System.out.println("A carregar...");
    }

    public void loaded(String fileName){
        System.out.println("Ficheiro " + fileName + " carregado");
    }

    public void showPageLista(String titulo, List<String> lista, int page, int pageSize, int numPages, int listSize){
        showTitle();
        int index;
        int pageWidth = 8;
        int maxPageSize = 64;

        System.out.println(titulo + " : " + listSize + "\n");
    
        for (int i = 0; i * pageWidth < pageSize; i++){
            for(int j = 0; (j < pageWidth) && (j + (i * pageWidth)  < pageSize) ; j++){
                index = j + (i * pageWidth) + (maxPageSize  * (page-1));
                if(index < listSize) System.out.print((index + 1) + " - " + lista.get(index) + " | ");
            }
            System.out.println("\n");
        }
        System.out.println();
    
        System.out.println("Página " + page + " de " + numPages);
        if (page > 1) System.out.println("1 - Página anterior ");
        if (page < numPages) System.out.println("2 - Página seguinte ");
        if (numPages > 1) System.out.println("3 - Saltar para página");
        System.out.println("Q - Retornar\n");

    }

    public void showPageMap(String titulo, Map<String, ? extends Number> map, int page, int pageSize, int numPages, int listSize){
        showTitle();
        int index;
        int pageWidth = 8;
        int maxPageSize = 64;

        Set<String> kS = map.keySet();
        DecimalFormat df = new DecimalFormat("#.##");

        System.out.println(titulo + " : " + listSize + "\n");
    
        for (int i = 0; i * pageWidth < pageSize; i++){
            for(int j = 0; (j < pageWidth) && (j + (i * pageWidth)  < pageSize) ; j++){
                index = j + (i * pageWidth) + (maxPageSize  * (page-1));
                if(index < listSize) System.out.print(kS.toArray()[index] + " - " + df.format(map.get(kS.toArray()[index])) + " | ");
            }
            System.out.println("\n");
        }
        System.out.println();
    
        System.out.println("Página " + page + " de " + numPages);
        if (page > 1) System.out.println("1 - Página anterior ");
        if (page < numPages) System.out.println("2 - Página seguinte ");
        if (numPages > 1) System.out.println("3 - Saltar para página");
        System.out.println("Q - Retornar\n");

    }

    public void showStatsVenda(IStatsVenda sv){
        showTitle();
        System.out.println("Ficheiro de Vendas lido : " + sv.getFile());
        System.out.println("Vendas erradas : " + sv.getVendasErradas());
        System.out.println("Total de Produtos : " + sv.getProdutos());
        System.out.println("Total de Produtos comprados: " + sv.getProdutosComprados());
        System.out.println("Total de Produtos não comprados : " + sv.getProdutosNaoComprados());
        System.out.println("Total de Clientes : " + sv.getClientes());
        System.out.println("Total de Clientes que realizaram compras : " + sv.getClientesCompram());
        System.out.println("Total de Clientes que nada compraram : " + sv.getClientesNaoCompram());
        System.out.println("Total de compras de valor 0.0 : " + sv.getVendasZero());
        System.out.println("Faturação total : " + sv.getFaturacaoTotal() + "\n");

        showENTER();
    }


    public void showStats1( int[] compras, double[][] totalFaturado, int[][] numClientes, double fatTotal){
        DecimalFormat df = new DecimalFormat("0.000E0");
        showTitle();
        
        System.out.println("Dados Estatísticos:\n");
        System.out.print("Número de compras: ");
        for(int c: compras){
            System.out.print(c + " | ");
        }
        System.out.println("\n\nTotal faturado:");
        for(int i = 0; i < 3; i++){
            System.out.print("\nFilial " + (i+1) + " : ");
            for(int j = 0; j < 12; j++){
                System.out.print(df.format(totalFaturado[i][j]) + " | ");
            }
            System.out.println();
        }

        System.out.println("\nFaturação total: " + df.format(fatTotal));

        System.out.println("\nNúmero de clientes distintos:");
        for(int i = 0; i < 3; i++){
            System.out.print("\nFilial " + (i+1) + " : ");
            for(int j = 0; j < 12; j++){
                System.out.print(numClientes[i][j] + " | ");
            }
            System.out.println();
        }
        System.out.println();

        

        showENTERReturn();
    }


    public void showQ2(int totvendas, int[] totvendasF,int totcompradores,int[]totcompradoresF, int mes){
        showTitle();
        System.out.println("\nMes: " + mes + "\n");
        for(int filial = 0; filial < 4; filial++){
            if(filial == 0){
                System.out.println("Resultados Globais:");
                System.out.print("Vendas totais: " + totvendas + " - ");
                System.out.println("Clientes distintos totais: " + totcompradores + "\n");
            }
            else {
                System.out.println("Filial " + filial + ":");
                System.out.print("Vendas: " + totvendasF[filial-1] + " - ");
                System.out.println("Clientes distintos: " + totcompradoresF[filial-1] + "\n");
            }
        }
        showENTER();
    }
    
    //numero de compras,quantos produtos,quanto gastou um cliente
    public void showQ3(int[] prodsComprados, double[] gasto, int[] nrCompras, String clienteID){
        showTitle();
        System.out.println("\nCliente: " + clienteID + "\n");
        for(int i = 0; i < 12; i++){
            System.out.println("Mes "+ (i+1));
            System.out.print("Nº de produtos comprados: " + prodsComprados[i] + " -");
            System.out.print(" Total gasto: " + String.format("%.2f", gasto[i])+ " -");
            System.out.println(" Nº de compras: " + nrCompras[i] + "\n");
        }

        showENTER();

    }

    //(produto) quantas vezes foi comprado, por quantos clientes diferentes e o total faturado
    public void showQ4(int[] nrVendas, double[] totalfaturado, int[] nrClientes, String produtoID) {
        showTitle();
        System.out.println("\nProduto: " + produtoID + "\n");       
        DecimalFormat df = new DecimalFormat("#.##");
        for(int i = 0; i < 12; i++){
            System.out.println("Mes "+ (i+1));
            System.out.print("Nº de vendas: " + nrVendas[i] + " -");
            System.out.print(" Total faturado: " + df.format(totalfaturado[i]) + " -");
            System.out.println(" Nº de clientes: " + nrClientes[i] + "\n");
        }
        showENTER();
    }


    public void showQ7(List<List<String>> compradores){
        showTitle();
        System.out.println("Maiores compradores\n");
        for(int i = 0; i < 3; i++){
            System.out.println("Filial " + (i+1) + " : " + compradores.get(i).toString());
        }
        
        showENTER();
    }

    public void showQ10(String produtoID, double[][] fat){
        int i = 0;
        DecimalFormat df = new DecimalFormat("#.##");
        showTitle();
        System.out.println("Produto :" + produtoID + "\n");
        for(double[] l: fat){
            i++;
            System.out.print("Filial " + i + " : ");
            for(double d: l){
                System.out.print(df.format(d) + " | ");
            }
            System.out.println("\n");
        }

        showENTER();
    }

    
}