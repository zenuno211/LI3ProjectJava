import Controller.*;

public class GestVendas {
    public static void main(String[] args){

        IGestVendasController controller = new GestVendasController();        
        controller.startController();

    }
    
}